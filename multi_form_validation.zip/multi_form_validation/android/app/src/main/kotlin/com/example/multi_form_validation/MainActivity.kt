package com.example.multi_form_validation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
